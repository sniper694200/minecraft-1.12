#!/bin/bash
./runtime/reobfuscate.py --srgnames "$@"
