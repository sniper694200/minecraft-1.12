#!/bin/bash
./runtime/startserver.py "$@"
